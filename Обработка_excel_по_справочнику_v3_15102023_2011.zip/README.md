# Используемые библиотеки и команды для их установки:
- pandas | pip install pandas
- openpyxl | pip install openpyxl
