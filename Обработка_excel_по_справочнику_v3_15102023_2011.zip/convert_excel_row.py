import pandas as pd
from base_options import Base_option
import json
import re
import time

from openpyxl import Workbook
from openpyxl.reader.excel import load_workbook
from openpyxl.styles import PatternFill

class Row_convert:
    def __init__(self, filename, options):
        self.filename = filename
        self.excel_data = None
        self.data = None
        self.option = Base_option()
        self.data_list = list()
        self.save_name = ""

    def check_param_json(self, param, data_json, type_car, i):
        for elem in data_json:
            if (str(type_car) == elem['TypeName']) and (str(param) == elem['ArticleNumber']) and (elem['Criterias'] != "[]"):
                criter = json.loads(elem['Criterias'])
                criter = [f"{criter[0]['key']} {criter[0]['value']}",]
                for pos in range(i+2):
                    criter.append("")
                criter.append(param)
                return criter                

    def modif_row(self, car_make, temp_car, type_car, data_json, id, prew_type):
        # получаем список с артиклями
        parameters = ["", "", ""]
        list_result = list()
        for i, elem in enumerate(self.option.title_result[3:]):
            param = self.data[elem][id]
            val = self.check_param_json(param, data_json[temp_car], type_car, i)
            if val != None:
                list_result.append(val)
                parameters.append(' ',)
            else:
                parameters.append(self.data[elem][id],)

        #если предыдущий type не совпадает с текущим, тогда добавляем
        if prew_type != type_car:
            # Добавляем строку (тип авто)
            self.data_list.append([type_car, self.data["КОД ДВИГАТЕЛЯ"][id], self.data["Мощность Л.С"][id]])
            # Добавляем строку с параметрами
            self.data_list.append(parameters)
        # Добавляем строки с результатом сопоставления
        self.data_list.extend(list_result)

    # Временная функция
    def save_excel(self):
        option = Base_option()
        
        df = pd.DataFrame(self.data_list, columns=option.title_result)
        timestr = time.strftime("%Y%m%d_%H%M%S")
        
        writer = pd.ExcelWriter("data_" + timestr + ".xlsx", engine='xlsxwriter') 
        df.to_excel(writer, sheet_name='my_analysis', index=False)
        writer.sheets['my_analysis'].set_column(1, 0, 25)
        writer.sheets['my_analysis'].set_column(2, 1, 10)
        writer.save()
        self.save_name = "data_" + timestr + ".xlsx"

    def convert_row(self):
        car_make, temp_car, prew_type = "", "", ""

        for i in range(len(self.data)):
            try:
                # Проверяем на марку модели
                if self.data["МОДЕЛЬ"][i].upper() in self.option.car_list:
                    self.data_list.append([self.data["МОДЕЛЬ"][i]])
                    # Обновляется каждый раз, когда встречается
                    car_make = self.data["МОДЕЛЬ"][i]
                else:
                    # открываем json-файл
                    with open(f'json/{car_make}.json', encoding="UTF-8") as json_file:
                        data_json = json.load(json_file)
                    
                    car1 = self.data["МОДЕЛЬ"][i]
                    # проверяем наличие даты в поле
                    if re.findall(r'[\s-]\d\d\.\d{4}', self.data["МОДЕЛЬ"][i]):
                        car = self.data["МОДЕЛЬ"][i].split(" ")
                        car = " ".join(car[:-1])
                    else:
                        car = self.data["МОДЕЛЬ"][i]

                    # Проверяем является ли значение моделью или типом
                    if car in data_json:
                        temp_car = car
                        self.data_list.append([car1])
                    else:
                        self.modif_row(car_make, temp_car, car, data_json, i, prew_type)  

                    # Обновляем prew_type 
                    prew_type = car 
            except:
                error_type = self.data["МОДЕЛЬ"][i]
                print(f"Error: {car_make} {temp_car} {error_type}")

    def color_row(self):
        wb = load_workbook(filename=self.save_name )
        ws = wb.active

        prev_row = "ACURA"
        for i in range(2, ws.max_row + 1):
            current_row = ws[i]
            try:
                with open(f'json/{prev_row}.json', encoding="UTF-8") as json_file:
                    data_json = json.load(json_file)
            except:
                print(f"Error: Не удалось открыть файл {prev_row}")

            # проверяем наличие даты в поле
            if re.findall(r'[\s-]\d\d\.\d{4}', str(current_row[0].value)):
                car = str(current_row[0].value).split(" ")
                car = " ".join(car[:-1])
            else:
                car = str(current_row[0].value)

            if str(current_row[0].value) in self.option.car_list:
                prev_row = str(current_row[0].value)
                for cell in current_row:
                    cell.fill = PatternFill(start_color="FF0000", end_color="FF0000", fill_type="solid")# красный
            elif car in data_json:
                for cell in current_row:
                    cell.fill = PatternFill(start_color="FF8300", end_color="FF8300", fill_type="solid")# оранжевый
            elif (str(current_row[0].value) == "None") or (str(current_row[1].value) != "None"):
                for cell in current_row:
                    cell.fill = PatternFill(start_color="F5F5DC", end_color="F5F5DC", fill_type="solid")# бежевый
            else:
                for cell in current_row:
                    cell.fill = PatternFill(start_color="F5F5DC", end_color="F5F5DC", fill_type="solid")# бежевый

        wb.save(self.save_name)

    def read_file(self):
        try:
            self.excel_data = pd.read_excel(self.filename)
            self.data = pd.DataFrame(self.excel_data)
        except:
            print("Проблема чтения файла!")

        self.convert_row()

#conv = Row_convert('res_art_criteria_1.xlsx', Base_option())
#conv.read_file()
#conv.color_row()