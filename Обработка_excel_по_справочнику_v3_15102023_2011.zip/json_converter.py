import pandas as pd
import time
from base_options import Base_option
import json

class Convert:
    def __init__(self, filename):
        self.filename = filename
        self.data = None
        self.excel_data = None
        self.data_dict = dict()

    def save_json_file(self):
        for key, elem in self.data_dict.items():
            # Serializing json
            json_object = json.dumps(elem, indent=4, ensure_ascii=False)
            
            # Writing to sample.json
            with open(f'json/{key}.json', "w", encoding="UTF-8") as outfile:
                outfile.write(json_object)        

    def read_excel_file(self):
        option = Base_option()
        self.excel_data = pd.read_excel(self.filename)
        self.data = pd.DataFrame(self.excel_data, columns=option.title_table) 
        for i in range(1, len(self.data)):
            car = self.data['Name'][i]
            model = self.data['VM'][i]

            if car not in self.data_dict:
                self.data_dict[car] = {
                    model: list()
                }

            if model not in self.data_dict[car]:
                self.data_dict[car][model] = list()

            self.data_dict[car][model].append(
                {
                    'Engines': self.data['Engines'][i],
                    'HorsePowers': str(self.data['HorsePowers'][i]),
                    'Volume': str(self.data['Volume'][i]),
                    'TypeName': self.data['TypeName'][i],
                    'ArticleNumber': self.data['ArticleNumber'][i],
                    'Criterias': self.data['Criterias'][i]
                }
            )
        self.save_json_file()

    def print_excel(self):
        option = Base_option()
        self.data = pd.DataFrame(self.excel_data, columns=option.title_table)   
        print("The content of the file is:\n", self.data[:20])
        print("\n"+"_________\n"+self.data["VM"][1])							