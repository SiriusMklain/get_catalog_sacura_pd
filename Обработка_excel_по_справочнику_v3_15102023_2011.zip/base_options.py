class Base_option:

    def __init__(self):
        self.title_table = [
            'Name', 'VM', 'Engines', 
            'HorsePowers', 'Year', 'Volume', 
            'TypeName', 'ArticleNumber', 'Criterias', 
            'GenericArticle'
        ]
        self.car_list = [
            'ACURA', 'OPEL', 'VOLVO', 'ALFA ROMEO', 'AUDI', 'BENTLEY', 'BMW', 'BOGDAN', 'BUICK',
            'CADILLAC', 'CHANGAN', 'CHERY', 'CHEVROLET', 'CHRYSLER', 'CITROËN', 'DACIA', 'DAEWOO',
            'DAIHATSU', 'DATSUN', 'DODGE', 'DS', 'EMGRAND', 'FIAT', 'FORD USA', 'FORD', 'FOTON', 
            'GAZ', 'GEELY', 'GENESIS', 'GMC', 'GREAT WALL', 'HAVAL', 'HONDA', 'HUMMER', 'HYUNDAI',
            'INFINITI', 'IRAN KHODRO', 'ISUZU', 'JAGUAR', 'JEEP', 'KAMAZ', 'KAWASAKI', 'KIA', 'LADA',
            'LAMBORGHINI', 'LANCIA', 'LAND ROVER', 'LDV', 'LEXUS', 'LIFAN', 'LINCOLN', 'LUXGEN', 'MASERATI',
            'MAZDA', 'MERCEDES-BENZ', 'MINI', 'MITSUBISHI', 'NISSAN (DFAC)', 'NISSAN', 'OPEL', 'PEUGEOT',
            'PLYMOUTH', 'PONTIAC', 'PORSCHE', 'RAM', 'RAVON', 'RENAULT', 'ROLLS-ROYCE', 'ROVER', 'SAAB',
            'SATURN', 'SCANIA', 'SCION', 'SEAT', 'SKODA', 'SMART', 'SSANGYONG', 'SUBARU', 'SUZUKI', 'TAGAZ',
            'TOYOTA (FAW)', 'TOYOTA (GAC)', 'TOYOTA', 'UZ-DAEWOO', 'VOLVO', 'VORTEX', 'VW', 'YAMAHA', 'ZAZ'
        ]
        self.title_result = [
            "МОДЕЛЬ",	"КОД ДВИГАТЕЛЯ",	"Мощность Л.С",	"Масляный фильтр",	"Топливный фильтр",
            "Воздушный фильтр",	"Спортивный воздушный фильтр",	"Радиатор, охлаждение двигателя",	
            "Конденсатор, кондиционер",	"Интеркулер",	"Гидрофильтр, автоматическая коробка передач",	
            "Комплект гидрофильтров, автоматическая коробка передач",	"Топливно-водяной сепаратор",	
            "Фильтр охлаждающей жидкости",	"Патрон осушителя воздуха, пневматическая система",	
            "Салонный фильтр CAC",	"Салонный фильтр CAB",	"Салонный фильтр CA"
        ]