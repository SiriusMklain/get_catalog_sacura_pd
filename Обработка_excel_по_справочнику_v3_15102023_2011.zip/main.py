from json_converter import Convert
from convert_excel_row import Row_convert
from base_options import Base_option
import time

def convert_json(url):
    conv = Convert(url) 
    conv.read_excel_file()
    print("Преобразование завершено!")

def convert_new_format(url):
    print("Обработка и сверка данных...")
    conv = Row_convert(url, Base_option()) 
    conv.read_file()
    conv.save_excel()
    print("Данные успешно сохранены!\nКрасим!")
    conv.color_row()
    print("Готово!")

def start():
    menu = "Выберите действие:\n1. Сохранить справку в json формат\n2. Сверить данные\n3. Выход"
    print(menu)
    n = input("Ввод: ")
    if n == "1":
        print('Укажите путь к файлу: ')
        convert_json(input())
    elif n == "2":
        s = time.time()
        print('Укажите путь к файлу: ')
        convert_new_format(input())
        print(f"Время затраченное на обработку: {time.time() - s}")
    elif n == "3":
        exit()
    else: 
        start()
    start()

if __name__ == "__main__":
    start()